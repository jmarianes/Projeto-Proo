package test;

import java.sql.*;

public class PessoaDAO {
    Connection conexao;

    public PessoaDAO() {
        conexao = new Conexao().getConexao();
    }

    public void inserirPessoa(Pessoa p) {
        try {
            PreparedStatement ps = conexao.prepareStatement(
                    "insert into Pessoa(nome, email, cpf, idade, cidade, usuario, senha) values(?,?,?,?,?,?,?)");
            ps.setString(1, p.getNome());
            ps.setString(2, p.getEmail());
            ps.setString(3, p.getCpf());
            ps.setInt(4, p.getIdade());
            ps.setString(5, p.getCidade());
            ps.setString(6, p.getUsuario());
            ps.setString(7, p.getSenha());
            ps.executeUpdate();
            System.out.println("\n Pessoa inserida com sucesso");
        } catch (Exception e) {
            System.out.println("Erro:" + e);
        }
    }

    public Pessoa logarPessoa(String senha, String usuario) {
        try {
            PreparedStatement ps = conexao.prepareStatement(
                    "SELECT nome,email,cpf,idade,cidade,usuario,senha FROM Pessoa WHERE usuario=? AND senha=? LIMIT 1;");
            ps.setString(1, usuario);
            ps.setString(2, senha);
            ResultSet rst = ps.executeQuery();
            Pessoa pessoa = null;
            while (rst.next()) {
                String nome = rst.getString(1);
                String email = rst.getString(2);
                String cpf = rst.getString(3);
                int idade = rst.getInt(4);
                String cidade = rst.getString(5);
                String usuarioString = rst.getString(6);
                String senhaString = rst.getString(7);
                pessoa = new Pessoa(nome, email, cpf, idade, cidade, usuarioString, senhaString);
            }
            return pessoa;
        } catch (Exception e) {
            System.out.println("Erro:" + e);
        }
        return null;
    }
    
    public void deletarPessoa(String cpf){
        try {
            PreparedStatement ps = conexao.prepareStatement("DELETE FROM Pessoa WHERE cpf = ?");
            ps.setString(1, cpf);
            ps.execute();
        } catch (Exception e) {
            System.out.println("Erro:" + e);
        }
    }
    
    
    
}
