package test;

import java.sql.*;
import java.util.ArrayList;

public class DogDAO {
    Connection conexao;

    public DogDAO() {
        conexao = new Conexao().getConexao();
    }

    public void inserirDog(Dog d) {
        try {
            PreparedStatement ps = conexao.prepareStatement("insert into Dog(nome,raca,idade,sexo) values(?,?,?,?)");
            ps.setString(1, d.getNome());
            ps.setString(2, d.getRaca());
            ps.setInt(3, d.getIdade());
            ps.setString(4, d.getSexo());
            ps.executeUpdate();
            System.out.println("\n Doguinho inserido com sucesso!!");
        } catch (Exception e) {
            System.out.println("Erro:" + e);
        }
    }

    public ArrayList<Dog> listarDogs() {
        ArrayList<Dog> dogs = new ArrayList<Dog>();
        try {
            PreparedStatement ps = conexao.prepareStatement("SELECT nome,raca,idade,sexo FROM Dog;");
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                String nome = rs.getString(1);
                String raca = rs.getString(2);
                int idade = rs.getInt(3);
                String sexo = rs.getString(4);
                Dog dog = new Dog(nome, raca, idade, sexo);
                dogs.add(dog);
            }
        } catch (Exception e) {
            System.out.println("Erro:" + e);
        }
        return dogs;
    }
}
